package poo;

public enum StatusPagamento {
    PENDENTE,
    APROVADO,
    RECUSADO,
    CANCELADO;
}